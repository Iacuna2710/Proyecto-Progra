package org.example;

public enum Posicion {
    PORTERO,
    DEFENSA,
    MEDIOCAMPISTA,
    DELANTERO
}
