package org.example;

import java.util.Random;


public class PlayerGeneration {
    private static String[] FirstName = {"Carlos", "Kevin", "Luis", "John", "Vinicius", "Lionel", "Wilson", "Juan", "Saul", "Daniel"};
    private static String[] LastName = {"Smith", "Moreno", "James", "Messi", "Da Silva", "Arguedas", "Quesada", "Rodriguez", "Layun"};

    public static void main(String[] args) {
        Player[] allPlayers = new Player[30];
        Team[] teams = new Team[3];
        Random random = new Random();

        for (int i = 0; i < 3; i++) {
            teams[i] = new Team();
        }


        for (int i = 0; i < 21; i++) {
            Player player = new Player("Player " + i, Posicion.values()[i % 4]);
            allPlayers[i] = player;
            teams[i % 3].addPlayer(player);
        }


        for (int i = 0; i < 30; i++) {
            String fullName = FirstName[random.nextInt(FirstName.length)] + " " + LastName[random.nextInt(LastName.length)];
            Player player = new Player(fullName, Posicion.values()[i % 4]);
            allPlayers[i] = player;
        }


        for (Player player : allPlayers) {
            if (player != null) {
                System.out.println("Player ID: " + player.getId() + ", Nombre Completo: " + player.getFullName() + ", Posicion: " + player.getPosicion() + ", Equipo: " + (player.getTeam() != null ? player.getTeam() : "No Equipo") + ", Estado: " + player.getEstado());
            }
        }

        for (Team team : teams) {
            System.out.println("Team Players:");
            for (Player player : team.getPlayers()) {
                if (player != null) {
                    System.out.println("- " + player.getFullName() + " (" + player.getPosicion() + ")");
                }
            }
        }
    }
}


