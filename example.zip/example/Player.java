package org.example;
public class Player {
    private static int nextId = 10;
    private int id;
    private String fullName;
    private Posicion posicion;
    private Team team;
    private Estado Estado;
    private int GolesAnotados;
    private int totalActions;

    public Player(String fullName, Posicion posicion) {
        this.id = nextId++;
        this.fullName = fullName;
        this.posicion = posicion;
        this.team = null;
        this.Estado = Estado.FREE;
        this.GolesAnotados = 0;
        this.totalActions = 0;
    }

    public String getFullName() {
        return fullName;
    }

    public int getId() {
        return id;
    }

    public Posicion getPosicion() {
        return posicion;
    }

    public Team getTeam() {
        return team;
    }

    public Estado getEstado() {
        return Estado;
    }


}

