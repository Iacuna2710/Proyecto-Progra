package org.example;

public enum Estado {
    STARTER,
    SUBSTITUTE,
    FREE
}
