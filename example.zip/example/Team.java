package org.example;

public class Team {
    private Player[] players;
    private int numPlayers;

    public Team() {
        this.players = new Player[7];
        this.numPlayers = 0;
    }

    public void addPlayer(Player player) {
        if (numPlayers < 7) {
            this.players[numPlayers++] = player;
        }
    }


    public Player[] getPlayers() {
        return players;
    }
}